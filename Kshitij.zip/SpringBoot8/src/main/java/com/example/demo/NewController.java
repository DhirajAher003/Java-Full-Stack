package com.example.demo;
import java.util.ArrayList;
import java.util.List;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class NewController {
	
	
	@GetMapping("/api")
	 public List<Product>getAllProduct()
	 {
		List<Product>products=new ArrayList<Product>();
		products.add(new Product("01","Shirts","599"));
		products.add(new Product("02","Pants","799"));
		products.add(new Product("03","Jacket","600"));
		products.add(new Product("04","Caps","100"));
		return products;
	 }
	
	
	
}
