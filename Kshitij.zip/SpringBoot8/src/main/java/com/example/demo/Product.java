package com.example.demo;
public class Product {

  private String ProductId;
  private String ProductName;
  private String ProductPrice;
  public Product() {
		
		// TODO Auto-generated constructor stub
	}
  public Product(String ProductId,String ProductName,String ProductPrice) {
	  this.ProductId=ProductId;
	  this.ProductName=ProductName;
	  this.ProductPrice=ProductPrice;
  }
public String getProductId() {
	return ProductId;
}
public void setProductId(String productId) {
	ProductId = productId;
}
public String getProductName() {
	return ProductName;
}

public void setProductName(String productName) {
	ProductName = productName;
}
public String getProductPrice() {
	return ProductPrice;
}
public void setProductPrice(String productPrice) {
	ProductPrice = productPrice;
}
}
